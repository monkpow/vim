
# generate timestamp : YYYYMMDD-mmss
timestamp=$(date +"%Y%m%d-%M%S")

