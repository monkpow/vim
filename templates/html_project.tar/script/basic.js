/*
 * -----------------------------------------------
 * Project   Basic Javascript Functions
 * Author:   Nik Krimm
 * ----------------------------------------------- */


/* =Page
 * ----------------------------------------------- */

var Page={
initialize:function(){
						 alert('hey'); 
					 }
}


window.onload=Page.initialize()
